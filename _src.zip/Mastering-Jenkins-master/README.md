## $5 Tech Unlocked 2021!
[Buy and download this Book for only $5 on PacktPub.com](https://www.packtpub.com/product/mastering-jenkins/9781784390891)
-----
*If you have read this book, please leave a review on [Amazon.com](https://www.amazon.com/gp/product/1784390895).     Potential readers can then use your unbiased opinion to help them make purchase decisions. Thank you. The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Mastering-Jenkins
Mastering Jenkins, published by Packt
